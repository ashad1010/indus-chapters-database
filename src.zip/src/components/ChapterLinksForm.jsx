// ChapterLinksForm.jsx
import React, { useState, useEffect } from 'react';

// This component collects WhatsApp and social media links
function ChapterLinksForm({ onUpdate }) {
  // 🧠 Track the WhatsApp link
  const [whatsappLink, setWhatsappLink] = useState('');

  // 🧠 Track multiple social media links (as an array of strings)
  const [socialLinks, setSocialLinks] = useState(['']); // Start with 1

  // ➕ Add an empty input field (if less than 5 total)
  const addSocialLink = () => {
    if (socialLinks.length < 5) {
      setSocialLinks([...socialLinks, '']);
    }
  };

  // ✏️ Update a specific social media link
  const handleSocialLinkChange = (index, value) => {
    const updated = [...socialLinks];
    updated[index] = value;
    setSocialLinks(updated);
  };

  // 🔁 Send both WhatsApp and social links to parent
  useEffect(() => {
    onUpdate({ whatsappLink, socialLinks });
  }, [whatsappLink, socialLinks, onUpdate]);

  return (
    <div>
      <h3>Step 3: Optional Group & Social Links</h3>

      {/* WhatsApp Group Input */}
      <label>WhatsApp Group Link:</label>
      <input
        type="text"
        value={whatsappLink}
        onChange={(e) => setWhatsappLink(e.target.value)}
        placeholder="https://chat.whatsapp.com/..."
      />

      <br /><br />

      {/* Render each social media input */}
      <label>Social Media Links (up to 5):</label>
      {socialLinks.map((link, index) => (
        <div key={index}>
          <input
            type="text"
            value={link}
            onChange={(e) => handleSocialLinkChange(index, e.target.value)}
            placeholder={`Link ${index + 1}`}
            style={{ marginBottom: '0.5rem', display: 'block' }}
          />
        </div>
      ))}

      {/* Add Link Button */}
      {socialLinks.length < 5 && (
        <button type="button" onClick={addSocialLink}>
          + Add Social Link
        </button>
      )}

      {/* Debug Output */}
      <br /><br />
      <pre>{JSON.stringify({ whatsappLink, socialLinks }, null, 2)}</pre>
    </div>
  );
}

export default ChapterLinksForm;
