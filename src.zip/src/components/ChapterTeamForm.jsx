// ChapterTeamForm.jsx
import React, { useState, useEffect } from 'react';

// This component lets the user add multiple team members
// and keeps track of them using React state.
function ChapterTeamForm({ onUpdate }) {
  // 🧠 teamMembers holds an array of member objects
  const [teamMembers, setTeamMembers] = useState([]);

  // ➕ This function adds a new empty member to the list
  const addNewMember = () => {
    if (teamMembers.length >= 15) return; // Limit to 15

    const newMember = {
      name: '',
      role: '',
      phone: '',
      email: '',
      title: '',
      note: '',
      status: '',
    };

    // 👇 Add the new member to the existing array
    setTeamMembers([...teamMembers, newMember]);
  };

  // ✏️ This function updates a specific field of a specific member
  const handleMemberChange = (index, field, value) => {
    const updated = [...teamMembers];       // copy the array
    updated[index][field] = value;          // update the specific field
    setTeamMembers(updated);                // set the new array
  };

  // 🔁 Whenever teamMembers changes, send it to the parent
  useEffect(() => {
    onUpdate(teamMembers);
  }, [teamMembers, onUpdate]);

  return (
    <div>
      <h3>Chapter Team Members</h3>

      {/* Add Member Button */}
      <button onClick={addNewMember}>+ Add New Member</button>

      {/* Render a form section for each team member */}
      {teamMembers.map((member, index) => (
        <div
          key={index}
          style={{
            border: '1px solid #ccc',
            padding: '1rem',
            marginTop: '1rem',
          }}
        >
          <h4>Member {index + 1}</h4>

          {/* Input for Name */}
          <label>Name:</label>
          <input
            type="text"
            value={member.name}
            onChange={(e) => handleMemberChange(index, 'name', e.target.value)}
          />

          {/* Input for Role */}
          <label>Role:</label>
          <input
            type="text"
            value={member.role}
            onChange={(e) => handleMemberChange(index, 'role', e.target.value)}
          />

          {/* Input for Phone */}
          <label>Phone:</label>
          <input
            type="text"
            value={member.phone}
            onChange={(e) => handleMemberChange(index, 'phone', e.target.value)}
          />

          {/* Input for Email */}
          <label>Email:</label>
          <input
            type="email"
            value={member.email}
            onChange={(e) => handleMemberChange(index, 'email', e.target.value)}
          />

          {/* Input for Title */}
          <label>Title:</label>
          <input
            type="text"
            value={member.title}
            onChange={(e) => handleMemberChange(index, 'title', e.target.value)}
          />

          {/* Input for Note */}
          <label>Note:</label>
          <input
            type="text"
            value={member.note}
            onChange={(e) => handleMemberChange(index, 'note', e.target.value)}
          />

          {/* Input for Status */}
          <label>Status:</label>
          <input
            type="text"
            value={member.status}
            onChange={(e) => handleMemberChange(index, 'status', e.target.value)}
          />
        </div>
      ))}

      {/* Optional: Show team data live as JSON (for debugging) */}
      <pre>{JSON.stringify(teamMembers, null, 2)}</pre>
    </div>
  );
}

export default ChapterTeamForm;
