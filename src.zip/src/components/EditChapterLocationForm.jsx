// EditChapterLocationForm.jsx
// This component allows editing of location data for a chapter (Country, City, Region, Name, Description)
// It is a clone of ChapterLocationForm but initialized with pre-filled data from props

import React, { useState, useEffect } from 'react';

function EditChapterLocationForm({ initialData, onUpdate }) {
  // Extract initial values or default to empty
  const {
    selectedCountry: initialCountry = '',
    selectedRegion: initialRegion = '',
    city: initialCity = '',
    chapterName: initialName = '',
    chapterDescription: initialDescription = ''
  } = initialData || {};

  // Local state for form fields
  const [countries, setCountries] = useState([]);        // All countries from API
  const [cities, setCities] = useState([]);              // Cities of selected country

  // Form state with initial values
  const [selectedCountry, setSelectedCountry] = useState(initialCountry);
  const [selectedCity, setSelectedCity] = useState(initialCity);
  const [selectedRegion, setSelectedRegion] = useState(initialRegion);
  const [chapterName, setChapterName] = useState(initialName);
  const [chapterDescription, setChapterDescription] = useState(initialDescription);

  // Fetch country list on mount
  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const res = await fetch('https://countriesnow.space/api/v0.1/countries');
        const json = await res.json();
        const countryList = json.data.map((item) => item.country);
        setCountries(countryList);
      } catch (err) {
        console.error('Error fetching countries:', err);
      }
    };
    fetchCountries();
  }, []);

  // Fetch cities when the selected country changes
  useEffect(() => {
    const fetchCities = async () => {
      if (!selectedCountry) return;
      try {
        const res = await fetch('https://countriesnow.space/api/v0.1/countries/cities', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ country: selectedCountry })
        });
        const json = await res.json();
        setCities(json.data);
      } catch (err) {
        console.error('Error fetching cities:', err);
        setCities([]);
      }
    };
    fetchCities();
  }, [selectedCountry]);

  // Inform parent of any changes
  useEffect(() => {
    onUpdate({
      selectedCountry,
      selectedRegion,
      city: selectedCity,
      chapterName,
      chapterDescription
    });
  }, [selectedCountry, selectedRegion, selectedCity, chapterName, chapterDescription]);

  return (
    <div>
      <h3>Edit Chapter Location</h3>

      {/* Country Dropdown */}
      <label>Country:</label>
      <select value={selectedCountry} onChange={(e) => setSelectedCountry(e.target.value)}>
        <option value="">-- Select a country --</option>
        {countries.map((country, idx) => (
          <option key={idx} value={country}>{country}</option>
        ))}
      </select>

      <br /><br />

      {/* City Dropdown */}
      <label>City:</label>
      <select
        value={selectedCity}
        onChange={(e) => setSelectedCity(e.target.value)}
        disabled={!cities.length}
      >
        <option value="">-- Select a city --</option>
        {cities.map((city, idx) => (
          <option key={idx} value={city}>{city}</option>
        ))}
      </select>

      <br /><br />

      {/* Region Text Input */}
      <label>State / Province:</label>
      <input
        type="text"
        value={selectedRegion}
        onChange={(e) => setSelectedRegion(e.target.value)}
        placeholder="Enter region"
      />

      <br /><br />

      {/* Chapter Name */}
      <label>Chapter Name:</label>
      <input
        type="text"
        value={chapterName}
        onChange={(e) => setChapterName(e.target.value)}
        placeholder="Enter chapter name"
      />

      <br /><br />

      {/* Chapter Description */}
      <label>Description:</label>
      <textarea
        rows={4}
        value={chapterDescription}
        onChange={(e) => setChapterDescription(e.target.value)}
        placeholder="Describe the chapter..."
      />
    </div>
  );
}

export default EditChapterLocationForm;
