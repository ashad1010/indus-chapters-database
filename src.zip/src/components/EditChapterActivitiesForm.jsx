// EditChapterActivitiesForm.jsx
// This component allows editing of a chapter's events/activities array
// It loads existing activity data, allows full editing, and syncs with parent via onUpdate()

import React, { useState, useEffect } from 'react';

function EditChapterActivitiesForm({ initialData = [], onUpdate }) {
  const [activities, setActivities] = useState(initialData);

  // Sync updates with parent component
  useEffect(() => {
    onUpdate({ events: activities });
  }, [activities]);

  // Add new blank activity (up to 15 total)
  const addNewActivity = () => {
    if (activities.length >= 15) return;
    const newActivity = {
      name: '',
      date: '',
      venue: '',
      ticketPrice: '',
      celebrityGuests: '',
      capacity: '',
      attendanceCount: '',
      sponsors: '',
      fundsCollected: ''
    };
    setActivities([...activities, newActivity]);
  };

  // Update individual field
  const handleActivityChange = (index, field, value) => {
    const updated = [...activities];
    updated[index][field] = value;
    setActivities(updated);
  };

  // Remove activity at index
  const removeActivity = (index) => {
    const updated = activities.filter((_, i) => i !== index);
    setActivities(updated);
  };

  return (
    <div>
      <h3>Edit Chapter Events</h3>
      <button onClick={addNewActivity}>+ Add New Event</button>

      {activities.map((activity, index) => (
        <div key={index} style={{ border: '1px solid #ccc', padding: '1rem', marginTop: '1rem' }}>
          <h4>Event {index + 1}</h4>
          <button onClick={() => removeActivity(index)} style={{ float: 'right', color: 'red' }}>✕ Remove</button>

          <label>Name:</label>
          <input
            type="text"
            value={activity.name}
            onChange={(e) => handleActivityChange(index, 'name', e.target.value)}
          />

          <label>Date:</label>
          <input
            type="date"
            value={activity.date}
            onChange={(e) => handleActivityChange(index, 'date', e.target.value)}
          />

          <label>Venue:</label>
          <input
            type="text"
            value={activity.venue}
            onChange={(e) => handleActivityChange(index, 'venue', e.target.value)}
          />

          <label>Ticket Price:</label>
          <input
            type="text"
            value={activity.ticketPrice}
            onChange={(e) => handleActivityChange(index, 'ticketPrice', e.target.value)}
          />

          <label>Celebrity Guests:</label>
          <input
            type="text"
            value={activity.celebrityGuests}
            onChange={(e) => handleActivityChange(index, 'celebrityGuests', e.target.value)}
          />

          <label>Capacity:</label>
          <input
            type="text"
            value={activity.capacity}
            onChange={(e) => handleActivityChange(index, 'capacity', e.target.value)}
          />

          <label>Total Attended:</label>
          <input
            type="text"
            value={activity.attendanceCount}
            onChange={(e) => handleActivityChange(index, 'attendanceCount', e.target.value)}
          />

          <label>Tickets & Sponsors:</label>
          <input
            type="text"
            value={activity.sponsors}
            onChange={(e) => handleActivityChange(index, 'sponsors', e.target.value)}
          />

          <label>Funds Collected:</label>
          <input
            type="text"
            value={activity.fundsCollected}
            onChange={(e) => handleActivityChange(index, 'fundsCollected', e.target.value)}
          />
        </div>
      ))}
    </div>
  );
}

export default EditChapterActivitiesForm;
