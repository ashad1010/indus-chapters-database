// ChapterActivitiesForm.jsx
import React, { useState, useEffect } from 'react';

// This component collects a list of events (chapter activities)
function ChapterActivitiesForm({ onUpdate }) {
  // 🧠 Store an array of activity objects
  const [activities, setActivities] = useState([]);

  // ➕ Add a blank activity entry (limit 15)
  const addNewActivity = () => {
    if (activities.length >= 15) return;

    const newActivity = {
      name: '',
      date: '',
      venue: '',
      ticketPrice: '',
      celebrityGuests: '',
      capacity: '',
      attendanceCount: '',
      sponsors: '',
      fundsCollected: '',
    };

    setActivities([...activities, newActivity]);
  };

  // ✏️ Update a specific field in one activity
  const handleActivityChange = (index, field, value) => {
    const updated = [...activities];
    updated[index][field] = value;
    setActivities(updated);
  };

  // 🔁 Send updated activities list to parent when it changes
  useEffect(() => {
    onUpdate(activities);
  }, [activities, onUpdate]);

  return (
    <div>
      <h3>Step 4: Chapter Activities & Events</h3>

      {/* Add New Event Button */}
      <button onClick={addNewActivity}>+ Add New Event</button>

      {/* Form section for each event */}
      {activities.map((activity, index) => (
        <div
          key={index}
          style={{ border: '1px solid #ccc', padding: '1rem', marginTop: '1rem' }}
        >
          <h4>Event {index + 1}</h4>

          <label>Name:</label>
          <input
            type="text"
            value={activity.name}
            onChange={(e) => handleActivityChange(index, 'name', e.target.value)}
          />

          <label>Date:</label>
          <input
            type="date"
            value={activity.date}
            onChange={(e) => handleActivityChange(index, 'date', e.target.value)}
          />

          <label>Venue:</label>
          <input
            type="text"
            value={activity.venue}
            onChange={(e) => handleActivityChange(index, 'venue', e.target.value)}
          />

          <label>Ticket Price:</label>
          <input
            type="text"
            value={activity.ticketPrice}
            onChange={(e) => handleActivityChange(index, 'ticketPrice', e.target.value)}
          />

          <label>Celebrity Guests:</label>
          <input
            type="text"
            value={activity.celebrityGuests}
            onChange={(e) => handleActivityChange(index, 'celebrityGuests', e.target.value)}
          />

          <label>Capacity:</label>
          <input
            type="text"
            value={activity.capacity}
            onChange={(e) => handleActivityChange(index, 'capacity', e.target.value)}
          />

          <label>Total Attended:</label>
          <input
            type="text"
            value={activity.attendanceCount}
            onChange={(e) => handleActivityChange(index, 'attendanceCount', e.target.value)}
          />

          <label>Tickets & Sponsors:</label>
          <input
            type="text"
            value={activity.sponsors}
            onChange={(e) => handleActivityChange(index, 'sponsors', e.target.value)}
          />

          <label>Funds Collected:</label>
          <input
            type="text"
            value={activity.fundsCollected}
            onChange={(e) => handleActivityChange(index, 'fundsCollected', e.target.value)}
          />
        </div>
      ))}

      {/* Debug Output */}
      <br />
      <pre>{JSON.stringify(activities, null, 2)}</pre>
    </div>
  );
}

export default ChapterActivitiesForm;
