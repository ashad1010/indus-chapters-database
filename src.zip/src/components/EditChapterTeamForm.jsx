// EditChapterTeamForm.jsx
// This component allows editing of the team_members array
// It preloads existing data and syncs updates back to the parent using onUpdate()

import React, { useState, useEffect } from 'react';

function EditChapterTeamForm({ initialData = [], onUpdate }) {
  // Clone initialData into local state
  const [teamMembers, setTeamMembers] = useState(initialData);

  // Update parent on every change
  useEffect(() => {
    onUpdate({ team_members: teamMembers });
  }, [teamMembers]);

  // Add a new empty member (max 15)
  const addNewMember = () => {
    if (teamMembers.length >= 15) return;
    const newMember = {
      name: '',
      role: '',
      phone: '',
      email: '',
      title: '',
      note: '',
      status: ''
    };
    setTeamMembers([...teamMembers, newMember]);
  };

  // Handle field change
  const handleMemberChange = (index, field, value) => {
    const updated = [...teamMembers];
    updated[index][field] = value;
    setTeamMembers(updated);
  };

  // Remove member at index
  const removeMember = (index) => {
    const updated = teamMembers.filter((_, i) => i !== index);
    setTeamMembers(updated);
  };

  return (
    <div>
      <h3>Edit Chapter Team Members</h3>
      <button onClick={addNewMember}>+ Add Member</button>

      {teamMembers.map((member, index) => (
        <div key={index} style={{ border: '1px solid #ccc', padding: '1rem', marginTop: '1rem' }}>
          <h4>Member {index + 1}</h4>

          <button onClick={() => removeMember(index)} style={{ float: 'right', color: 'red' }}>
            ✕ Remove
          </button>

          <label>Name:</label>
          <input
            type="text"
            value={member.name}
            onChange={(e) => handleMemberChange(index, 'name', e.target.value)}
          />

          <label>Role:</label>
          <input
            type="text"
            value={member.role}
            onChange={(e) => handleMemberChange(index, 'role', e.target.value)}
          />

          <label>Phone:</label>
          <input
            type="text"
            value={member.phone}
            onChange={(e) => handleMemberChange(index, 'phone', e.target.value)}
          />

          <label>Email:</label>
          <input
            type="email"
            value={member.email}
            onChange={(e) => handleMemberChange(index, 'email', e.target.value)}
          />

          <label>Title:</label>
          <input
            type="text"
            value={member.title}
            onChange={(e) => handleMemberChange(index, 'title', e.target.value)}
          />

          <label>Note:</label>
          <input
            type="text"
            value={member.note}
            onChange={(e) => handleMemberChange(index, 'note', e.target.value)}
          />

          <label>Status:</label>
          <input
            type="text"
            value={member.status}
            onChange={(e) => handleMemberChange(index, 'status', e.target.value)}
          />
        </div>
      ))}
    </div>
  );
}

export default EditChapterTeamForm;
