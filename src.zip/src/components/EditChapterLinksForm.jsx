// EditChapterLinksForm.jsx
// This component allows editing of WhatsApp group link and up to 5 social media links
// It uses dynamic inputs for the socialLinks array and syncs all changes to parent via onUpdate()

import React, { useState, useEffect } from 'react';

function EditChapterLinksForm({ initialData, onUpdate }) {
  // Destructure values from initial data or default to blank
  const {
    whatsappLink = '',
    socialLinks = []
  } = initialData || {};

  // State: single WhatsApp link and array of social links
  const [whatsapp, setWhatsapp] = useState(whatsappLink);
  const [links, setLinks] = useState(socialLinks);

  // Push updated structure to parent whenever inputs change
  useEffect(() => {
    onUpdate({
      social_links: {
        whatsappLink: whatsapp,
        socialLinks: links
      }
    });
  }, [whatsapp, links]);

  // Update individual link value in array
  const handleLinkChange = (index, value) => {
    const newLinks = [...links];
    newLinks[index] = value;
    setLinks(newLinks);
  };

  // Add a new blank input field (max 5)
  const addLink = () => {
    if (links.length < 5) {
      setLinks([...links, '']);
    }
  };

  // Remove a specific link
  const removeLink = (index) => {
    const newLinks = links.filter((_, i) => i !== index);
    setLinks(newLinks);
  };

  return (
    <div>
      <h3>Edit Chapter Social Links</h3>

      {/* WhatsApp Link */}
      <label>WhatsApp Group Link:</label>
      <input
        type="url"
        value={whatsapp}
        onChange={(e) => setWhatsapp(e.target.value)}
        placeholder="https://chat.whatsapp.com/..."
      />
      <br /><br />

      {/* Dynamic Social Media Links */}
      <label>Social Media Links (up to 5):</label>
      {links.map((link, index) => (
        <div key={index} style={{ display: 'flex', marginBottom: '0.5rem' }}>
          <input
            type="url"
            value={link}
            onChange={(e) => handleLinkChange(index, e.target.value)}
            placeholder={`Link ${index + 1}`}
            style={{ flex: 1 }}
          />
          <button
            onClick={() => removeLink(index)}
            style={{ marginLeft: '0.5rem' }}
          >
            ✕
          </button>
        </div>
      ))}

      {/* Add More Button */}
      {links.length < 5 && (
        <button onClick={addLink} style={{ marginTop: '0.5rem' }}>
          + Add Social Link
        </button>
      )}
    </div>
  );
}

export default EditChapterLinksForm;