// ChapterReviewForm.jsx
import React from 'react';

function ChapterReviewForm({ data, onSubmit }) {
  return (
    <div style={{ marginTop: '2rem' }}>
      <h3>Step 5: Review & Submit</h3>
      <p>Please confirm the information below:</p>

      {/* Display JSON of final object for now */}
      <pre style={{
        background: '#222',
        padding: '1rem',
        borderRadius: '5px',
        color: 'lime',
        fontSize: '0.9rem',
      }}>
        {JSON.stringify(data, null, 2)}
      </pre>

      <br />

      {/* Final submission button */}
      <button onClick={onSubmit}>Submit Chapter Data</button>
    </div>
  );
}

export default ChapterReviewForm;
