// Home.jsx
import React from 'react';

function Home() {
  return (
    <div>
      <h2>Welcome to Indus Chapter Dashboard</h2>
      <p>Use the buttons to navigate:</p>
    </div>
  );
}

export default Home;
