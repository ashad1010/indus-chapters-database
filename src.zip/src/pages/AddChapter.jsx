// AddChapter.jsx
import React, { useState } from 'react';
import ChapterLocationForm from '../components/ChapterLocationForm';
import ChapterTeamForm from '../components/ChapterTeamForm';
import ChapterLinksForm from '../components/ChapterLinksForm';
import ChapterActivitiesForm from '../components/ChapterActivitiesForm';
import ChapterReviewForm from '../components/ChapterReviewForm';
import { supabase } from '../supabaseClient';

function AddChapter() {
  const [locationData, setLocationData] = useState({});
  const [teamData, setTeamData] = useState([]);
  const [linkData, setLinkData] = useState({ whatsappLink: '', socialLinks: [] });
  const [activityData, setActivityData] = useState([]);
  const [showReview, setShowReview] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const finalChapter = {
    location: {
      chapterName: locationData.chapterName || '',
      selectedCountry: locationData.selectedCountry || '',
      selectedRegion: locationData.selectedRegion || '',
      city: locationData.city || '',
      chapterDescription: locationData.chapterDescription || '',
    },
    team_members: teamData,
    social_links: linkData,
    events: activityData,
    description: locationData.chapterDescription || '',
  };

  const handleSubmit = async () => {
    setSubmitting(true);
  
    const { data, error } = await supabase
      .from('chapters')
      .insert([finalChapter]);
  
    if (error) {
      console.error('❌ Supabase insert error:', error);
      alert(`❌ Error saving chapter: ${error.message}`);
    } else {
      alert('✅ Chapter saved to database!');
    }
  
    setSubmitting(false);
  };
  

  return (
    <div>
      <h2>Add a New Chapter</h2>

      <ChapterLocationForm onUpdate={setLocationData} />
      <hr style={{ margin: '2rem 0' }} />

      <ChapterTeamForm onUpdate={setTeamData} />
      <hr style={{ margin: '2rem 0' }} />

      <ChapterLinksForm onUpdate={setLinkData} />
      <hr style={{ margin: '2rem 0' }} />

      <ChapterActivitiesForm onUpdate={setActivityData} />
      <hr style={{ margin: '2rem 0' }} />

      {!showReview && (
        <button onClick={() => setShowReview(true)}>
          Review & Submit
        </button>
      )}

      {showReview && (
        <ChapterReviewForm
          data={finalChapter}
          onSubmit={handleSubmit}
          isSubmitting={submitting}
        />
      )}
    </div>
  );
}

export default AddChapter;
