import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/Home';
import AddChapter from './pages/AddChapter';
import ViewChapters from './pages/ViewChapters';

function App() {
  return (
    <Router>
      {/* Main app layout */}
      <div>

        {/* Navigation Bar */}
        <nav style={{
          padding: '1rem',
          background: '#ddd',
          color: '#222'
        }}>
          {/* Center the nav content only */}
          <div style={{ maxWidth: '900px', margin: '0 auto' }}>
            <Link to="/" style={{ marginRight: '1rem' }}>Home</Link>
            <Link to="/add" style={{ marginRight: '1rem' }}>Add Chapter</Link>
            <Link to="/view">View Chapters</Link>
          </div>
        </nav>

        {/* Main Page Content */}
        <main style={{ padding: '2rem 1rem' }}>
          <div style={{ maxWidth: '900px', margin: '0 auto' }}>
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/add" element={<AddChapter />} />
              <Route path="/view" element={<ViewChapters />} />
            </Routes>
          </div>
        </main>

      </div>
    </Router>
  );
}

export default App;
